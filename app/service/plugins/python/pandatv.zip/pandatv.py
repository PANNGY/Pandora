# -*- coding: utf-8 -*-
import urllib2,re,time
from urlparse import parse_qsl
import sys
import json
import android

reload(sys)
sys.setdefaultencoding('utf-8')

class __redirection__:
    def __init__(self):
        self.buff = ''
        self.__console__ = sys.stdout

    def write(self, output_stream):
        self.buff += output_stream

    def to_console(self):
        sys.stdout = self.__console__
        print self.buff

    def to_file(self, file_path):
        f = open(file_path, 'w')
        sys.stdout = f
        print self.buff
        f.close()

    def flush(self):
        self.buff = ''

    def reset(self):
        sys.stdout = self.__console__

def post(url, data):
    req = urllib2.Request(url)
    opener = urllib2.build_opener(urllib2.HTTPCookieProcessor())
    response = opener.open(req, data)
    return response.read()

def list_categories(args):

    f = urllib2.urlopen('http://api.m.panda.tv/ajax_get_all_subcate?__version=1.0.5.1098&__plat=iOS')

    obj = json.loads(f.read())

    for category in obj['data']:

        print "{{'id': '{0}', 'title': '{1}', 'thumbnail': '{2}'}}".format(category['ename'], category['cname'], (('http:' + category['img']) if category['img'][:4] != 'http' else category['img']))

def list_videos(args):

    apiurl = "http://api.m.panda.tv/ajax_get_live_list_by_cate";
    params = "__plat=iOS&__version=1.0.5.1098&cate={ename}&order=person_num&pageno=1&pagenum=100&status=2".format(ename=args[0])

    returndata = post(apiurl, params);

    obj = json.loads(returndata)

    for video in obj['data']['items']:

        print "{{'id': '{0}', 'title': '{1}', 'thumbnail': '{2}'}}".format(video['id'], video['name'], (('http:' + video['pictures']['img']) if video['pictures']['img'][:4] != 'http' else video['pictures']['img']))

def list_video_infos(args):

    f = urllib2.urlopen('http://www.panda.tv/api_room?roomid={room_id}'.format(room_id=args[0]))
    obj = json.loads(f.read())
    path = 'http://pl3.live.panda.tv/live_panda/{video}.flv'.format(video=obj['data']['videoinfo']['room_key'])

    print "{{'id': '{0}', 'title': '{1}', 'thumbnail': '{2}', 'url': '{3}'}}".format(obj['data']['videoinfo']['room_key'], obj['data']['roominfo']['name'], (('http:' + obj['data']['hostinfo']['avatar']) if obj['data']['hostinfo']['avatar'][:4] != 'http' else obj['data']['hostinfo']['avatar']), path)

def execute_command(args=sys.argv[1:]):
    droid = android.Android()
    token = args[len(args) - 1];
    command = args[0]
    commands = {
        'list_categories': list_categories,
        'list_videos': list_videos,
        'list_video_infos': list_video_infos,
        }
    r_obj = __redirection__()
    sys.stdout = r_obj
    commands[command](args[1:])
    droid.terminalNotify(token, r_obj.buff);

if __name__ == '__main__':
    execute_command()
