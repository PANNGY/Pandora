# -*- coding: utf-8 -*-
import urllib2,re,time
from urlparse import parse_qsl
import sys
import json
import android

reload(sys)
sys.setdefaultencoding('utf-8')

class __redirection__:
    def __init__(self):
        self.buff = ''
        self.__console__ = sys.stdout

    def write(self, output_stream):
        self.buff += output_stream

    def to_console(self):
        sys.stdout = self.__console__
        print self.buff

    def to_file(self, file_path):
        f = open(file_path, 'w')
        sys.stdout = f
        print self.buff
        f.close()

    def flush(self):
        self.buff = ''

    def reset(self):
        sys.stdout = self.__console__

def list_categories(args):

    f = urllib2.urlopen('http://www.zhanqi.tv/api/static/game.lists/100-1.json?rand={ts}'.format(ts=time.time()))

    obj = json.loads(f.read())

    for category in obj['data']['games']:

        print "{{'id': '{0}', 'title': '{1}', 'thumbnail': '{2}'}}".format(category['id'], category['name'], (('http:' + category['bpic']) if category['bpic'][:4] != 'http' else category['bpic']))

def list_videos(args):

    f = urllib2.urlopen('http://www.zhanqi.tv/api/static/game.lives/{category_id}/100-1.json?rand={ts}'.format(category_id=args[0], ts=time.time()))

    obj = json.loads(f.read())

    for video in obj['data']['rooms']:

        print "{{'id': '{0}', 'title': '{1}', 'thumbnail': '{2}'}}".format(video['id'], video['title'], (('http:' + video['bpic']) if video['bpic'][:4] != 'http' else video['bpic']))

def list_video_infos(args):

    f = urllib2.urlopen('http://www.zhanqi.tv/api/static/live.roomid/{video_id}.json?sid='.format(video_id=args[0]))

    obj = json.loads(f.read())

    if obj['data'].has_key('videoIdKey') :
	    path = 'rtmp://wsrtmp.load.cdn.zhanqi.tv/zqlive/{video}'.format(video=obj['data']['videoIdKey'])

	    print "{{'id': '{0}', 'title': '{1}', 'thumbnail': '{2}', 'url': '{3}'}}".format(obj['data']['videoIdKey'], obj['data']['title'], (('http:' + obj['data']['bpic']) if obj['data']['bpic'][:4] != 'http' else obj['data']['bpic']), path)
    else :
	    path = 'rtmp://wsrtmp.load.cdn.zhanqi.tv/zqlive/{video}'.format(video=obj['data']['videoId'])

	    print "{{'id': '{0}', 'title': '{1}', 'thumbnail': '{2}', 'url': '{3}'}}".format(obj['data']['videoId'], obj['data']['title'], (('http:' + obj['data']['bpic']) if obj['data']['bpic'][:4] != 'http' else obj['data']['bpic']), path)

def execute_command(args=sys.argv[1:]):
    droid = android.Android()
    token = args[len(args) - 1];
    command = args[0]
    commands = {
        'list_categories': list_categories,
        'list_videos': list_videos,
        'list_video_infos': list_video_infos,
        }
    r_obj = __redirection__()
    sys.stdout = r_obj
    commands[command](args[1:])
    droid.terminalNotify(token, r_obj.buff);

if __name__ == '__main__':
    execute_command()
