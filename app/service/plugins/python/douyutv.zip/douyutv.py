# -*- coding: utf-8 -*-

from contextlib import contextmanager, closing, nested
import requests
import urllib2,re
from bs4 import BeautifulSoup
from urlparse import parse_qsl
import sys
import json,urllib
import hashlib,time,uuid
import HTMLParser
import logging
from douyudanmu import douyudanmu
from Douyu import Douyu_HTTP_Server
import sys
import android

reload(sys)
sys.setdefaultencoding('utf-8')

class __redirection__:
    def __init__(self):
        self.buff = ''
        self.__console__ = sys.stdout

    def write(self, output_stream):
        self.buff += output_stream

    def to_console(self):
        sys.stdout = self.__console__
        print self.buff

    def to_file(self, file_path):
        f = open(file_path, 'w')
        sys.stdout = f
        print self.buff
        f.close()

    def flush(self):
        self.buff = ''

    def reset(self):
        sys.stdout = self.__console__

pars=HTMLParser.HTMLParser()
API_URL = "http://www.douyutv.com/swf_api/room/{0}?cdn={1}&nofan=yes&_t={2}&sign={3}"
API_SECRET = u'bLFlashflowlad92'
headers={'Accept':
     'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8','Accept-Encoding': 'gzip, deflate','User-Agent':'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:16.0) Gecko/20100101 Firefox/16.0'}
#Initialize logging
logging.getLogger().setLevel(logging.INFO)
logging.basicConfig(format='[%(module)s][%(funcName)s] %(message)s')

def list_categories(args):

    rr=BeautifulSoup(requests.get('http://www.douyutv.com/directory',headers=headers).text, "html.parser")

    catel=rr.findAll('a',{'class':'thumb'})

    rrr=[(x['href'], x.p.text,x.img['data-original']) for x in catel]

    for classname,textinfo,img in rrr:

        print "{{'id': '{0}', 'title': '{1}', 'thumbnail': '{2}'}}".format(classname, textinfo, (('http:' + img) if img[:4] != 'http' else img))

def list_videos(args):

    rr=BeautifulSoup(requests.get('http://www.douyu.com'+args[0],headers=headers).text, "html.parser")

    videol=rr.findAll('a',{'class':'play-list-link'})

    for x in videol:
        roomid=x['href'][1:]
        img=x.img['data-original']
        title=x['title']
        nickname=x.find('span',{'class':'dy-name ellipsis fl'}).text
        view=x.find('span',{'class':'dy-num fr'}).text
        liveinfo=u'{0}#{1}#{2}'.format(title,nickname,view)

        print "{{'id': '{0}', 'title': '{1}', 'thumbnail': '{2}'}}".format(roomid, liveinfo, (('http:' + img) if img[:4] != 'http' else img))

def list_video_infos(args):

    cdn = ""
    html = requests.get('http://www.douyu.com/'+args[0],headers=headers).text
    match = re.search(r'"room_id"\s*:\s*(\d+),', html)
    if match:
        if match.group(0) != u'0':
            roomid = match.group(1)

    json_request_url = "http://m.douyu.com/html5/live?roomId=%s" % roomid
    res = json.loads(requests.get(json_request_url,headers=headers).text)
    status = res.get('error', 0)
    if status is not 0:
        logging.error('Unable to get information for roomid: %s' % (roomid))
        return
    data = res['data']
    if data['show_status'] != u'1':
        logging.error('The live stream is not online.')
        return
    img=data['avatar']
    roomname=data['room_name']
    path = data['hls_url']

    print "{{'id': '{0}', 'title': '{1}', 'thumbnail': '{2}', 'url': '{3}'}}".format(roomid, roomname, (('http:' + img) if img[:4] != 'http' else img), path)

def execute_command(args=sys.argv[1:]):
    droid = android.Android()
    token = args[len(args) - 1];
    command = args[0]
    commands = {
        'list_categories': list_categories,
        'list_videos': list_videos,
        'list_video_infos': list_video_infos,
        }
    r_obj = __redirection__()
    sys.stdout = r_obj
    commands[command](args[1:])
    droid.terminalNotify(token, r_obj.buff);

if __name__ == '__main__':
    execute_command()
