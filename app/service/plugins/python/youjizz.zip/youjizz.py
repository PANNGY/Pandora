import urllib, requests, re, sys
import android

reload(sys)
sys.setdefaultencoding('utf-8')

class __redirection__:
    def __init__(self):
        self.buff = ''
        self.__console__ = sys.stdout

    def write(self, output_stream):
        self.buff += output_stream

    def to_console(self):
        sys.stdout = self.__console__
        print self.buff

    def to_file(self, file_path):
        f = open(file_path, 'w')
        sys.stdout = f
        print self.buff
        f.close()

    def flush(self):
        self.buff = ''

    def reset(self):
        sys.stdout = self.__console__

headers = { 'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.95 Safari/537.36'}

BASE_URL = 'https://www.youjizz.com'

def addDir(name, url, mode):
	print "{{'id': '{0}', 'name': '{1}'}}".format("url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name), name)

def list_categories(args):
	addDir('Newest', BASE_URL + '/newest-clips/1.html', 1)
	addDir('Top Rated', BASE_URL + '/top-rated/1.html', 1)
	addDir('Random Videos', BASE_URL + '/random.php', 1)

def getHtml(url):
    try:
        return requests.get(url,headers=headers).text
    except:
        return ''

def addDownLink(name, url, mode, iconimage):
	if iconimage != None:
		print "{{'id': '{0}', 'title': '{1}', 'thumbnail': '{2}'}}".format("url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&thumbnail=" + urllib.quote_plus(iconimage), name, iconimage)
	else:
		print "{{'id': '{0}', 'title': '{1}'}}".format("url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name), name)

def INDEX(url):
    link = getHtml(url)
    matchname = re.compile('title1">[\n]{0,1}\s*(.+?)<').findall(link)
    matchurl = re.compile('class="frame" href=\'\/videos\/.+?(\d+).html'
                         ).findall(link)
    matchthumb = re.compile('data-original="([^"]+jpg)').findall(link)
    matchduration = re.compile('thumbtime\'><span.*>(\d{1,}:\d{2})'
                              ).findall(link)
    for name, url, thumb, duration in zip(matchname, matchurl, matchthumb,
                                       matchduration):
            url = '/videos/embed/' + url
            addDownLink(name + ' ' + '(' + duration + ')',
                        url,
                        2,
                        thumb)
    matchpage = re.compile('pagination[\s\S]+?<span>\d{1,}<\/span>'
                           '[\s\S]+?href="(.+?html)').findall(link)
    for nexturl in matchpage:
            addDownLink('next', BASE_URL + '' + nexturl, 1, None)

def list_videos(args):
    dict = {}

    for item in args[0].split('&'):
        dict[item.split('=')[0]] = item.split('=')[1]

	url = urllib.unquote_plus(dict['url'])

	INDEX(url)

def VIDEOLINKS(url, name, thumbnail):
    link = getHtml(BASE_URL + '' + url)
    match = re.compile('src="(?:https:)?//([^"]+\.mp4[^"]+)').findall(link)
    if not match:
        print "Failed to find video URL"
    for url in match:
		print "{{'id': '{0}', 'title': '{1}', 'thumbnail': '{2}', 'url': '{3}'}}".format(urllib.unquote_plus(url), name, thumbnail, 'https://' + url);

def list_video_infos(args):

    dict = {}

    for item in args[0].split('&'):
        dict[item.split('=')[0]] = item.split('=')[1]

    url = urllib.unquote_plus(dict['url'])
    name = urllib.unquote_plus(dict['name'])
    thumbnail = urllib.unquote_plus(dict['thumbnail'])
    VIDEOLINKS(url, name, thumbnail)

def execute_command(args=sys.argv[1:]):
    droid = android.Android()
    token = args[len(args) - 1];
    command = args[0]
    commands = {
        'list_categories': list_categories,
        'list_videos': list_videos,
        'list_video_infos': list_video_infos
        }
    r_obj = __redirection__()
    sys.stdout = r_obj
    commands[command](args[1:])
    droid.terminalNotify(token, r_obj.buff);

if __name__ == '__main__':
    execute_command()